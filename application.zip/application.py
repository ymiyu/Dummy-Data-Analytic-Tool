import pandas as pd
import numpy as np
import hdbscan
import warnings
import urllib.parse
import plotly.graph_objects as go
import dash
import dash_table as dt
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
from datetime import datetime
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler, FunctionTransformer
from sklearn.utils.random import sample_without_replacement
from sklearn.manifold import TSNE
pd.options.mode.chained_assignment = None
warnings.filterwarnings("ignore")

external_stylesheets = ["https://fonts.googleapis.com/css?family=Open+Sans:300,400,700", "https://codepen.io/chriddyp/pen/bWLwgP.css"]

app = dash.Dash(__name__, external_stylesheets = external_stylesheets)

app.title = "Clustering Tool"

app.css.config.serve_locally = True
app.scripts.config.serve_locally = True

application = app.server

app.layout = html.Div(children=[

    # first panel
    html.Details(id="first_panel", open=False, children=[

        html.Summary(children=[

            html.Label(children=["Data Preprocessing"], style={"font-size": "120%", "margin": "1vw 0vw 1vw 0.5vw",
                "display": "inline-block", "vertical-align": "middle"}),

            html.Button(children=["Open"], id="first_panel_button", n_clicks=1, style={"margin": "1vw 0vw 1vw 0.5vw",
            "color": "white", "background-color": "#66C2A5", "display": "inline-block", "vertical-align": "middle"}),

        ], style={"height": "5vw"}),

        html.Div(children=[

            html.Div(children=[

                # dropdown used for selecting the input file with the dataset
                html.Div(children=[

                    html.Label("Dataset:", style={"margin": "1vw 0vw 0.3vw 0vw"}),
                    dcc.Dropdown(id="selected_file", options=[{"label": "Adult", "value": "adult"}], value="adult",
                        style={"font-size": "95%"}, placeholder="Select Data", optionHeight=35, multi=False,
                                 clearable=False, searchable=True),

                ], style={"margin": "0vw 0vw 0vw 1vw", "width": "16%", "display": "inline-block",
                            "vertical-align": "top"}),

                # dropdown used for selecting the columns of the dataset
                html.Div(children=[

                    html.Label("Columns:", style={"margin": "1vw 0vw 0.3vw 0vw"}),
                    dcc.Dropdown(id="selected_columns", style={"font-size": "95%"}, optionHeight=35,
                                 multi=True, searchable=True, clearable=True, placeholder="Select Columns"),

                ], style={"margin": "0vw 0vw 0vw 1vw", "width": "16%", "display": "inline-block",
                          "vertical-align": "top"}),

                # dropdown used for selecting the rows of the dataset
                html.Div(children=[

                    html.Label("Rows:", style={"margin": "1vw 0vw 0.3vw 0vw"}),
                    dcc.Dropdown(id="selected_rows", style={"font-size": "95%"}, optionHeight=35, multi=True,
                        searchable=True, clearable=True, placeholder="Select Rows"),

                ], style={"margin": "0vw 0vw 0vw 1vw", "width": "16%", "display": "inline-block",
                          "vertical-align": "top"}),

                # radio buttons used for selecting the approach for numerical missing values
                html.Div(children=[

                    html.Label("Missing Numerical Values:", style={"margin": "1vw 0vw 1vw 0vw"}),
                    dcc.RadioItems(id="missing_numerical", value="drop", options=[{"label": "Mean", "value": "mean"},
                        {"label": "Median", 'value': "median"}, {"label": "Mode", "value": "mode"},
                            {"label": "Drop", 'value': "drop"}], labelStyle={"font-size": "95%",
                                "display": "inline-block", "margin": "0vw 0.5vw 0vw 0vw"}),

                ], style={"margin": "0vw 0vw 0vw 1vw", "width": "21%", "display": "inline-block",
                          "vertical-align": "top"}),

                # radio buttons used for selecting the approach for categorical missing values
                html.Div(children=[

                    html.Label("Missing Categorical Values:", style={"margin": "1vw 0vw 1vw 0vw"}),
                    dcc.RadioItems(id="missing_categorical", value="drop", options=[{"label": "Mode", "value": "mode"},
                        {"label": "Drop", 'value': "drop"}], labelStyle={"font-size": "95%", "display": "inline-block",
                            "margin": "0vw 0.5vw 0vw 0vw"}),

                ], style={"margin": "0vw 0vw 0vw 0vw", "width": "16%", "display": "inline-block",
                          "vertical-align": "top"}),

                # run button used for updating the table after making a selection
                html.Div(children=[

                    html.Label("Update Table:", style={"margin": "1vw 0vw 0.3vw 0vw"}),
                    html.Button(id="table_button", n_clicks=0, children=["update"],
                        style={"background-color": "#F46D43", "font-size": "80%", "font-weight": "500",
                                "text-align": "center", "width": "99%", "color": "white"}),

                ], style={"margin": "0vw 0vw 0vw 0.5vw", "width": "9%", "display": "inline-block",
                          "vertical-align": "top"}),

            ], className="row"),

        ]),

        # spinner
        dcc.Loading(children=[

            # table with the selected data
            html.Div(children=[

                dt.DataTable(id="data_table", style_as_list_view=False, style_data_conditional=
                  [{"if": {"row_index": "odd"}, "background-color": "#ffffd2"}], style_table={"display": "block",
                  "max-height": "31vw", "max-width": "97%", "overflow-y": "scroll", "margin": "2vw 1vw 2vw 1vw"},
                  style_cell={"text-align": "center", "font-family": "Open Sans", "font-size": "90%", "height": "2vw"},
                  style_header={"background-color": "#66C2A5", "text-align": "center", "color": "white",
                    "text-transform": "uppercase", "font-family": "Open Sans", "font-size": "85%",
                        "font-weight": "500", "height": "2vw"})

            ], className="row", style={"height": "33vw", "width": "100%", "margin-bottom": "2vw"}),

        ], type="circle", color="#F46D43", style={"height": "33vw", "margin-bottom": "2vw", "width": "100%",
                        "position": "relative", "top": "15vw"}),

    ], className="row"),

    # second panel
    html.Details(id="second_panel", open=False, children=[

        html.Summary(children=[

            html.Label(children=["Exploratory Data Analysis"], style={"font-size": "120%", "margin": "1vw 0vw 1vw 0.5vw",
                "display": "inline-block", "vertical-align": "middle"}),

            html.Button(children=["Open"], id="second_panel_button", n_clicks=1, style={"margin": "1vw 0vw 1vw 0.5vw",
            "color": "white", "background-color": "#66C2A5", "display": "inline-block", "vertical-align": "middle"}),

        ], style={"height": "5vw"}),

        html.Div(children=[

            html.Div(children=[

                # dropdown used for selecting the features
                html.Label("Features:", style={"margin": "1vw 0vw 0.5vw 1vw"}),
                dcc.Dropdown(id="selected_features", style={"font-size": "95%", "margin-left": "0.5vw"},
                    optionHeight=35, multi=True, searchable=True, clearable=True, placeholder="Select Features"),

                # radio buttons used for selecting the transformation
                html.Label("Transformation:", style={"margin": "2vw 0vw 0.5vw 1vw"}),
                dcc.RadioItems(id="features_transformation", value="none", options= [{"label": "Logarithm",
                  "value": "log"}, {"label": "Z-score", "value": "z-score"}, {"label": "None", "value": "none"}],
                    labelStyle={"font-size": "95%", "display": "inline-block", "margin": "0vw 0.5vw 0vw 0vw"},
                        style={"margin-left": "1vw"}),

                # run button used for updating the results
                html.Label("Update Results:", style={"margin": "2vw 0vw 0.3vw 1vw"}),
                html.Button(id="stats_button", n_clicks=0, children=["update"], style={"background-color": "#F46D43",
                    "font-size": "80%", "margin-left": "1vw", "font-weight": "500", "text-align": "center",
                       "width": "60%", "color": "white"}),

                # explanatory text
                html.P(children=["Note that the correlation matrix can display at most 10 features."],
                         style={"margin": "1vw 0vw 1vw 1vw", "font-size": "95%"})

            ], className="three columns"),

            # correlation matrix
            html.Div(children=[

                html.Label("Correlation Matrix:", style={"margin": "1vw 0vw 0.5vw 2vw"}),

                dcc.Loading(children=[

                    dcc.Graph(id="correlation_matrix", config={"responsive": True, "autosizable": True,
                        "showTips": True, "displaylogo": False}, style={"height": "28vw", "width": "60vw",
                            "margin": "0vw 0vw 0vw 3vw"}),

                ], type="circle", color="#F46D43", style={"height": "28vw", "width": "60vw", "margin-left": "3vw",
                        "position": "relative", "top": "10vw"}),

             ], className="nine columns", style={"height": "30vw"}),

        ], className="row"),

        # table with the descriptive statistics
        html.Div(children=[

            html.Label("Descriptive Statistics:", style={"margin": "1vw 0vw 0.5vw 1vw"}),

            dcc.Loading(children=[

                dt.DataTable(id="stats_table", style_as_list_view=False, style_data_conditional=[
                  {"if": {"row_index": "odd"}, "background-color": "#ffffd2"}, {"if": {"column_id": "Stat."},
                    "background-color": "#66C2A5", "color": "white"}], style_table={"display": "block",
                   "max-width": "97%", "overflow-y": "scroll", "margin": "0vw 0vw 2vw 1vw"}, style_cell={"text-align":
                   "center", "font-family": "Open Sans", "font-size": "90%", "height": "2vw"}, style_header={
                   "background-color": "#66C2A5", "text-align": "center", "color": "white", "text-transform":
                    "uppercase", "font-family": "Open Sans", "font-size": "85%", "font-weight": "500", "height": "2vw"})

            ], type="circle", color="#F46D43", style={"height": "25vw", "width": "100%",
                    "position": "relative", "top": "5vw"}),

        ], className="row", style={"width": "100%", "height": "25vw"}),

    ], className="row", style={"border-top": "1px solid #212121"}),

    # third panel
    html.Details(id="third_panel", open=False, children=[

        html.Summary(children=[

            html.Label(children=["Cluster Analysis"], style={"font-size": "120%", "margin": "1vw 0vw 1vw 0.5vw",
                          "display": "inline-block", "vertical-align": "middle"}),

            html.Button(children=["Open"], id="third_panel_button", n_clicks=1, style={"margin": "1vw 0vw 1vw 0.5vw",
            "color": "white", "background-color": "#66C2A5", "display": "inline-block", "vertical-align": "middle"}),

        ], style={"height": "5vw"}),

        html.Div(children=[

            html.Div(children=[

                # dropdown used for selecting the features
                html.Div([

                    html.Label("Features:", style={"margin": "1vw 0vw 0.5vw 0vw"}),
                    dcc.Dropdown(id="cluster_features", style={"font-size": "95%"}, optionHeight=35, multi=True,
                        searchable=True, clearable=True, placeholder="Select Features"),

                ],style={"margin-left": "1vw"}),

                # dropdown used for selecting the weights of the features
                html.Div([

                    html.Label("Weights:", style={"margin": "1vw 0vw 0vw 0vw"}),
                    html.P("The number of weights must be equal to the number of features.", style={"font-size": "80%"}),
                    dcc.Dropdown(id="cluster_weights", style={"font-size": "95%"}, optionHeight=35, multi=True,
                            searchable=True, clearable=True, placeholder="Enter Weights"),

                ],style={"margin-left": "1vw"}),

                # radio buttons used for selecting the transformation
                html.Label("Transformation:", style={"margin": "1vw 0vw 0.5vw 1vw"}),
                dcc.RadioItems(id="cluster_transform", value="none", options=[{"label": "Logarithm",
                    "value": "log"}, {"label": "Z-score", "value": "z-score"}, {"label": "None", "value": "none"}],
                        labelStyle={"font-size": "95%", "display": "inline-block", "margin": "0vw 0.5vw 0vw 0vw"},
                            style={"margin-left": "1vw"}),

                # radio buttons used for choosing whether to perform random sampling
                html.Label("Random Sampling:", style={"margin": "1vw 0vw 0.5vw 1vw"}),
                dcc.RadioItems(id="random_sampling", value=False, options=[{"label": "True", "value": True},
                    {"label": "False", "value": False}], labelStyle={"font-size": "95%", "display": "inline-block",
                        "margin": "0vw 0.5vw 0vw 0vw"}, style={"margin-left": "1vw"}),

                # numeric input for entering the size of the subsample
                html.Label("Sample Size:", style={"margin": "1vw 0vw 0vw 1vw"}),
                html.P("If using random sampling, enter the size of the subsample as an integer between 1 "
                     "(corresponding to 1%) and 100 (corresponding to 100%).",
                       style={"font-size": "80%", "margin-left": "1vw", "text-align": "justify"}),
                dcc.Input(id="sample_size", type="number", min=1, max=100, placeholder=80, style={"margin-left": "1vw"}),

                # radio buttons used for selecting the dimension reduction technique
                html.Label("Dimension Reduction:", style={"margin": "1vw 0vw 0.5vw 1vw"}),
                dcc.RadioItems(id="dimension_reduction", value="pca", options=[{"label": "PCA", "value": "pca"},
                    {"label": "T-SNE", "value": "tsne"}, {"label": "None", "value": "none"}],
                      labelStyle={"font-size": "95%", "display": "inline-block", "margin": "0vw 0.5vw 0vw 0vw"},
                               style={"margin-left": "1vw"}),

                # numeric input for entering the number of components
                html.Label("Number of Components:", style={"margin": "1vw 0vw 0vw 1vw"}),
                html.P("If using PCA or T-SNE, enter the number of components.",
                       style={"font-size": "80%", "margin-left": "1vw", "text-align": "justify"}),
                dcc.Input(id="num_components", type="number", placeholder=3, value=3, min=1, style={"margin-left": "1vw"}),

                # radio buttons used for selecting the clustering algorithm
                html.Label("Clustering Algorithm:", style={"margin": "1vw 0vw 0.5vw 1vw"}),
                dcc.RadioItems(id="cluster_algorithm", value="kmeans", options=[{"label": "K-Means", "value": "kmeans"},
                     {"label": "HDBSCAN", "value": "hdbscan"}], labelStyle={"font-size": "95%", "display": "inline-block",
                        "margin": "0vw 0.5vw 0vw 0vw"}, style={"margin-left": "1vw"}),

                # numeric input for entering the number of clusters
                html.Label("Number of Clusters:", style={"margin": "1vw 0vw 0vw 1vw"}),
                html.P("If using K-Means, enter the number of clusters.", style={"font-size": "80%",
                                "margin-left": "1vw", "text-align": "justify"}),
                dcc.Input(id="num_clusters", type="number", placeholder=3, value=3, min=1, style={"margin-left": "1vw"}),

                # numeric input for entering the minimum cluster size
                html.Label("Minimum Cluster Size:", style={"margin": "1vw 0vw 0vw 1vw"}),
                html.P("If using HDBSCAN, enter the minimum cluster size.",
                       style={"font-size": "80%", "margin-left": "1vw", "text-align": "justify"}),
                dcc.Input(id="cluster_size", type="number", placeholder=2, min=2, value=2, style={"margin-left": "1vw"}),

                # run button used for updating the results
                html.Label("Update Results:", style={"margin": "1vw 0vw 0.3vw 1vw"}),
                html.Button(id="cluster_button", n_clicks=0, children=["update"], style={"background-color": "#F46D43",
                    "font-size": "80%", "margin-left": "1vw", "font-weight": "500", "text-align": "center",
                         "width": "60%", "color": "white"}),

            ], className="four columns", style={"width": "26%", "display": "inline-block", "vertical-align": "top"}),

            # scatter plot
            html.Div(children=[

                html.Div(children=[

                    html.Div(children=[

                        # dropdown used for selecting the feature to plot on the X axis
                        html.Label("X-Axis:", style={"margin": "1vw 0vw 0.5vw 0vw"}),
                        dcc.Dropdown(id="x-axis", style={"font-size": "95%"}, optionHeight=35,
                            multi=False, searchable=True, clearable=True, placeholder="Select Feature"),

                    ], style={"display": "inline-block", "width": "30%", "margin-left": "1vw"}),

                    html.Div(children=[

                        # dropdown used for selecting the feature to plot on the Y axis
                        html.Label("Y-Axis:", style={"margin": "1vw 0vw 0.5vw 0vw"}),
                        dcc.Dropdown(id="y-axis", style={"font-size": "95%"}, optionHeight=35,
                            multi=False, searchable=True, clearable=True, placeholder="Select Feature"),

                    ], style={"display": "inline-block", "width": "30%", "margin-left": "2vw"}),

                    html.Div(children=[

                        # dropdown used for selecting the feature to plot on the Z axis
                        html.Label("Z-Axis:", style={"margin": "1vw 0vw 0.5vw 0vw"}),
                        dcc.Dropdown(id="z-axis", style={"font-size": "95%"}, optionHeight=35,
                            multi=False, searchable=True, clearable=True,  placeholder="Select Feature"),

                    ], style={"display": "inline-block", "width": "30%", "margin-left": "2vw"}),

                ], className="row"),

                # spinner
                dcc.Loading(children=[

                    # graph
                    dcc.Graph(id="cluster_plot", config={"responsive": True, "autosizable": True,
                        "showTips": True, "displaylogo": False}, style={"height": "40vw", "width": "60vw",
                             "margin": "0em 0em 0em 0em", "padding": "-3em 0em 0em 3em"}),

                ], type="circle", color="#F46D43", style={"height": "40vw", "width": "60vw", "position": "relative",
                         "top": "18vw", "margin": "0em 0em 0em 0em", "padding": "-3em 0em 0em 3em"}),

                # alerts
                html.Div(children=[

                    html.Label("Alerts:", style={"margin": "0vw 0vw 0.5vw 2vw"}),

                    dcc.Loading(children=[

                        html.Div(children=[

                            html.P(id="features_message", style={"font-size": "85%", "margin": "1vw 0vw 0vw 2vw", "text-align": "justify"}),
                            html.P(id="weights_message", style={"font-size": "85%", "margin": "1vw 0vw 0vw 2vw", "text-align": "justify"}),
                            html.P(id="transform_message", style={"font-size": "85%", "margin": "1vw 0vw 0vw 2vw", "text-align": "justify"}),
                            html.P(id="sample_message", style={"font-size": "85%", "margin": "1vw 0vw 0vw 2vw", "text-align": "justify"}),
                            html.P(id="reduction_message", style={"font-size": "85%", "margin": "1vw 0vw 0vw 2vw", "text-align": "justify"}),
                            html.P(id="algo_message", style={"font-size": "85%", "margin": "1vw 0vw 0vw 2vw", "text-align": "justify"}),
                            html.P(id="cluster_message", style={"font-size": "85%", "margin": "1vw 0vw 0vw 2vw", "text-align": "justify"}),
                            html.P(children=["Done."], style={"font-size": "85%", "margin": "1vw 0vw 0vw 2vw", "text-align": "justify"}),

                        ],style={"height": "12vw", "width": "48vw"}),

                    ], type="circle", color="#F46D43", style={"height": "12vw", "width": "48vw",
                             "background-color": "#ffffd2", "position": "relative", "top": "5vw", "left": "4vw"}),

                ], style={"height": "22vw", "background-color": "#ffffd2", "padding-top": "1vw",
                        "border": "1px solid #d9d9d9", "border-radius": "0.5rem", "margin": "0vw 4vw 0vw 2vw"}),

            ], className="eight columns", style={"display": "inline-block", "vertical-align": "top"}),

        ], className="row"),

        html.Div(children=[

            html.Label(children=["Clustering Results:"], style={"font-size": "120%", "margin": "1vw 0vw 0.5vw 1vw",
                "display": "inline-block", "vertical-align": "middle", "width": "20%"}),

            # table
            dcc.Loading(children=[

                dt.DataTable(id="cluster_table", style_as_list_view=False, style_data_conditional=[
                    {"if": {"row_index": "odd"}, "background-color": "#ffffd2"}], style_table={"display": "block",
                      "max-width": "97%", "max-height": "25vw", "overflow-y": "scroll", "margin": "0vw 0vw 1vw 1vw"},
                      style_cell={"text-align": "center", "font-family": "Open Sans", "font-size": "90%",
                      "height": "2vw"}, style_header={"background-color": "#66C2A5", "text-align": "center",
                      "color": "white", "text-transform": "uppercase", "font-family": "Open Sans", "font-size": "85%",
                      "font-weight": "500", "height": "2vw"})

            ], type="circle", color="#F46D43", style={"height": "25vw", "width": "100%",
                        "position": "relative", "top": "10vw"}),

            # download button
            html.A(id="link", target="_blank", children=[

                html.Button(id="download_button", children=["Download CSV"], style={"margin": "0vw 0vw 2vw 1vw",
                              "background-color": "#99D594", "font-size": "80%", "font-weight": "500"}),

            ], style={"display": "inline-block"}),

        ], className="row", style={"width": "100%", "height": "25vw", "margin-bottom": "10vw"}),

    ], className="row", style={"border-top": "1px solid #212121"}),

    # hidden divs; these are used for storing the data shared across callbacks
    html.Div(children=[

        html.Div(id="initial_data", style={"display": "none"}),
        html.Div(id="selected_data", style={"display": "none"}),
        html.Div(id="clustering_output", style={"display": "none"}),

    ], className="row", style={"border-top": "1px solid #212121"})

])

@app.callback([Output("first_panel", "open"), Output("first_panel_button", "children")],
              [Input("first_panel_button", "n_clicks")])
def first_panel(n_clicks):
    if n_clicks % 2 != 0:
        return [False, "Open"]
    else:
        return [True, "Close"]

@app.callback([Output("second_panel", "open"), Output("second_panel_button", "children")],
              [Input("second_panel_button", "n_clicks")])
def second_panel(n_clicks):
    if n_clicks % 2 != 0:
        return [False, "Open"]
    else:
        return [True, "Close"]

@app.callback([Output("third_panel", "open"), Output("third_panel_button", "children")],
              [Input("third_panel_button", "n_clicks")])
def third_panel(n_clicks):
    if n_clicks % 2 != 0:
        return [False, "Open"]
    else:
        return [True, "Close"]

@app.callback([Output("selected_rows", "options"), Output("selected_columns", "options"),
               Output("cluster_weights", "options"), Output("initial_data","children")],
              [Input("selected_file", "value")])
def load_data(selected_file):

    if selected_file=="adult":

        # import the data
        df = pd.read_csv("data/adult.csv")
        columns = list(df.columns)
        rows = list(df.index)

        # process the missing values
        df[df == "-"] = np.nan
        df[df == "?"] = np.nan
        df[df == "."] = np.nan
        df[df == " "] = np.nan

        # include the row ids in the first columns
        df["id"] = rows
        names = ["id"]
        names.extend(columns)
        df = df[names]

        # save the data in the hidden div
        data = df.to_json(orient="split")

        # transform the categorical variables into dummy variables
        df = pd.get_dummies(df, dummy_na=False, drop_first=True)

        # get the new column ids
        columns = list(df.columns)
        columns.remove("id")

        # create the list of column ids to be shown in the dropdown menu
        column_options = [{"value": columns[0], "label": columns[0]}]

        if len(columns) > 1:
           for j in range(1, len(columns)):
               column_options.append({"value": columns[j], "label": columns[j]})

        # create the list of row ids to be shown in the dropdown menu
        row_options = [{"value": rows[0], "label": rows[0]}]

        if len(rows) > 1:
            for j in range(1, len(rows)):
                row_options.append({"value": rows[j], "label": rows[j]})

        # delete the unnecessary objects
        del df, names, rows, columns

        # create the list of weights to be shown in the dropdown menu
        weights_options = [{"value": 0, "label": 0}]

        for j in range(1, 1000):
            weights_options.append({"value": j, "label": j})

    return [row_options, column_options, weights_options, {"data": data}]

@app.callback([Output("data_table", "data"), Output("data_table", "columns"), Output("selected_data", "children"),
               Output("selected_features", "options"), Output("cluster_features", "options")],
              [Input("table_button", "n_clicks"), Input("initial_data", "children")],
              [State("selected_rows", "value"), State("selected_columns", "value"),
               State("missing_numerical", "value"), State("missing_categorical", "value")])
def update_table(n_clicks, initial_data, selected_rows, selected_columns, missing_numerical, missing_categorical):

    # load the initial data from the hidden div
    df = pd.read_json(initial_data["data"], orient="split")

    # process the missing values
    num = df.loc[:, np.logical_and(df.dtypes != "object", df.dtypes != "category")]

    if missing_numerical == "drop":

        num.dropna(inplace=True)
        df = df.iloc[num.index, :]
        df.reset_index(inplace=True, drop=True)

    elif missing_numerical == "mean":

        keys = list(num.columns)
        values = list(num.mean(axis=0).round().values.flatten())
        df.fillna(value=dict(zip(keys, values)), inplace=True)

    elif missing_numerical == "median":

        keys = list(num.columns)
        values = list(num.median(axis=0).round().values.flatten())
        df.fillna(value=dict(zip(keys, values)), inplace=True)

    elif missing_numerical == "mode":

        keys = list(num.columns)
        values = list(num.mode(axis=0).round().values.flatten())
        df.fillna(value=dict(zip(keys, values)), inplace=True)

    cat = df.loc[:, np.logical_or(df.dtypes == "object", df.dtypes == "category")]

    if missing_categorical == "drop":

        cat.dropna(inplace=True)
        df = df.iloc[cat.index, :]
        df = pd.get_dummies(df, dummy_na=False, drop_first=True)
        df.reset_index(inplace=True, drop=True)

    elif missing_categorical == "mode":

        keys = list(cat.columns)
        values = list(cat.mode(axis=0).values.flatten())
        df.fillna(value=dict(zip(keys, values)), inplace=True)
        df = pd.get_dummies(df, dummy_na=False, drop_first=True)

    # extract the selected rows and columns
    if selected_columns is not None and selected_rows is not None:

        columns = list(set(selected_columns))
        indices = list(set(selected_rows))

        if len(columns) > 0:

            names = ["id"]
            names.extend(columns)

        else:

            names = list(df.columns)

        if len(indices) > 0:

            rows = list(df.index[df["id"].isin(indices)])

        else:

            rows = list(df.index)

    elif selected_columns is None and selected_rows is not None:

        names = list(df.columns)
        indices = list(set(selected_rows))

        if len(indices) > 0:

            rows = list(df.index[df["id"].isin(indices)])

        else:

            rows = list(df.index)

    elif selected_columns is not None and selected_rows is None:

        columns = list(set(selected_columns))
        rows = list(df.index)

        if len(columns) > 0:

            names = ["id"]
            names.extend(columns)

        else:

            names = list(df.columns)

    else:

        names = list(df.columns)
        rows = list(df.index)

    df = df[names].iloc[rows, :]
    df.reset_index(inplace=True, drop=True)

    # display the data in the table
    table_data = df.to_dict("records")
    table_columns = [{"id": x, "name": x} for x in list(df.columns)]

    # save the selected data in the hidden div
    data = df.to_json(orient="split")

    # create the list of features to be shown in the dropdown menu
    # in the exploratory data analysis section
    names.remove("id")
    features_options = [{"value": names[0], "label": names[0]}]

    if len(names) > 1:
        for j in range(1, len(names)):
            features_options.append({"value": names[j], "label": names[j]})

    # display the same list of features in the dropdown menu
    # in the clustering section
    cluster_features = features_options

    # delete the unnecessary objects
    del df, names, rows

    return [table_data, table_columns, {"data": data}, features_options, cluster_features]

@app.callback([Output("stats_table", "data"), Output("stats_table", "columns"), Output("correlation_matrix", "figure")],
              [Input("stats_button", "n_clicks"), Input("selected_data", "children")],
              [State("selected_features", "value"), State("features_transformation", "value")])
def exploratory_data_analysis(n_clicks, selected_data, selected_features, features_transformation):

    # load the selected data from the hidden div
    df = pd.read_json(selected_data["data"], orient="split")
    df.drop("id", axis=1, inplace=True)

    # extract the selected features
    if selected_features is not None:
        if len(selected_features) > 0:
            df = df[list(selected_features)]

    # apply the selected transformation
    if features_transformation == "log":

        df = pd.DataFrame(data=FunctionTransformer(np.log1p, validate=True).fit_transform(df),
                          columns=df.columns, index=df.index)

    elif features_transformation == "z-score":

        df = pd.DataFrame(data=StandardScaler().fit_transform(df), columns=df.columns, index=df.index)

    # calculate the descriptive statistics
    stats = df.describe()

    # round all values to 2 digits
    stats = stats.astype(float).round(2)

    # add the names of the descriptive statistics in the first column
    stats["Stat."] = stats.index
    names = ["Stat."]
    names.extend(list(stats.columns[stats.columns!="Stat."]))
    stats = stats[names]

    # display the descriptive statistics in the table
    table_data = stats.to_dict("records")
    table_columns = [{"id": x, "name": x} for x in list(stats.columns)]

    # calculate the sample correlation matrix
    sigma = df.iloc[:,:10].corr()
    x = list(sigma.columns)
    y = list(sigma.index)
    z = np.nan_to_num(sigma.values)

    # plot the sample correlation matrix
    annotations = []
    for i in range(z.shape[0]):
        for j in range(z.shape[1]):
            annotations.append(dict(x=x[i], y=y[j], text=str(np.round(z[i,j]*100,2))+"%", showarrow=False))

    # chart layout
    layout = dict(annotations=annotations, margin=dict(t=30), xaxis=dict(tickangle=45), yaxis=dict(tickangle=0),
                  font=dict(family="Open Sans", size=10))

    # chart traces
    traces = []
    traces.append(go.Heatmap(z=z, x=x, y=y, zmin=-1, zmax=1, colorscale="Spectral"))

    # chart object
    correlation_matrix = go.Figure(data=traces, layout=layout).to_dict()

    return [table_data, table_columns, correlation_matrix]

@app.callback([Output("cluster_table", "data"), Output("cluster_table", "columns"), Output("x-axis", "options"),
               Output("y-axis", "options"), Output("z-axis", "options"), Output("clustering_output", "children"),
               Output("features_message", "children"), Output("weights_message", "children"),
               Output("transform_message", "children"), Output("sample_message", "children"),
               Output("reduction_message", "children"), Output("algo_message", "children"),
               Output("cluster_message", "children")],
              [Input("cluster_button", "n_clicks"), Input("selected_data", "children")],
              [State("cluster_features", "value"), State("cluster_weights", "value"),
               State("cluster_transform", "value"), State("random_sampling", "value"),
               State("sample_size", "value"), State("dimension_reduction", "value"),
               State("num_components", "value"), State("cluster_algorithm", "value"),
               State("num_clusters", "value"), State("cluster_size", "value")])
def cluster_analysis(n_clicks, selected_data, cluster_features, cluster_weights, cluster_transform, random_sampling,
                     sample_size, dimension_reduction, num_components, cluster_algorithm, num_clusters, cluster_size):

    # load the selected data from the hidden div
    df = pd.read_json(selected_data["data"], orient="split")

    # save the rows ids
    records = df["id"]

    # drop the row ids
    df.drop("id", axis=1, inplace=True)

    # extract the selected features
    if cluster_features is not None:

        if len(cluster_features) > 0:

            df = df[list(cluster_features)]

            features_message = "Extracting " + str(len(cluster_features)) + " features."

        else:

            features_message = "No features selected. Using all features."

    else:

        features_message = "No features selected. Using all features."

    # extract the new number of columns
    n = df.shape[1]

    # apply the weights
    if cluster_weights is not None:

        if len(cluster_weights) == n:

            cluster_weights = cluster_weights / np.sum(cluster_weights)

            weights_message = "Applying weights to features."

            for i in range(n):

                df.iloc[:, i] = df.iloc[:, i] * cluster_weights[i]

        else:

            weights_message = "The number of weights is different from the number of features. No weights applied."

    else:

        weights_message = "No weights applied."

    # apply the selected transformation
    if cluster_transform == "log":

        df = pd.DataFrame(data=FunctionTransformer(np.log1p, validate=True).fit_transform(df),
                          columns=df.columns, index=df.index)

        transform_message = "Calculating logarithms."

    elif cluster_transform == "z-score":

        df = pd.DataFrame(data=StandardScaler().fit_transform(df), columns=df.columns, index=df.index)

        transform_message = "Calculating z-scores."

    else:

        transform_message = "No transformation applied."

    # perform random sampling
    if random_sampling == True:

        if sample_size is not None:

            # add back the row ids
            df["id"] = records

            # calculate the number of samples
            n_samples = np.int(sample_size * df.shape[0] / 100)

            # generate the random sample
            indices = sample_without_replacement(n_population=df.shape[0], n_samples=n_samples, random_state=0)

            # extract the random sample
            df = df.iloc[indices, :]
            df.reset_index(inplace=True, drop=True)

            # extract the rows ids
            records = df["id"]

            # drop the row ids
            df.drop("id", axis=1, inplace=True)

            sample_message = "Sampling " + str(df.shape[0]) + " records."

        else:

            sample_message = "Sample size not selected. Random sampling not performed."

    else:

        sample_message = "Random sampling not performed."

    # perform dimension reduction
    if dimension_reduction == "pca":

        if num_components > 0 and num_components <= n:

            df = PCA(n_components=np.int(num_components), random_state=0).fit_transform(df)
            df = pd.DataFrame(data=df, columns=["Component " + str(x) for x in range(1, num_components + 1)])

            reduction_message = "Extracting " + str(num_components) + " components with PCA."

        else:

            reduction_message = "Invalid number of components. PCA not performed."

    elif dimension_reduction == "tsne":

        if num_components > 0 and num_components <= n:

            df = TSNE(n_components=np.int(num_components), random_state=0).fit_transform(df)
            df = pd.DataFrame(data=df, columns=["Component" + str(x) for x in range(1, num_components + 1)])

            reduction_message = "Extracting " + str(num_components) + " components with TSNE."

        else:

            reduction_message = "Invalid number of components. TSNE not performed."

    else:

        reduction_message = "Dimension reduction not performed."

    # run the clustering algorithm
    if cluster_algorithm == "kmeans":

        if num_clusters > 0 and num_clusters <= df.shape[0]:

            algo = KMeans(n_clusters=num_clusters, random_state=0).fit(df)

        else:

            algo = KMeans(n_clusters=3).fit(df)

        algo_message = "Running K-means."

    elif cluster_algorithm == "hdbscan":

        if cluster_size > 1 and cluster_size <= df.shape[0]:

            algo = hdbscan.HDBSCAN(min_cluster_size=cluster_size).fit(df)

        else:

            algo = hdbscan.HDBSCAN(min_cluster_size=2).fit(df)

        algo_message = "Running HDBSCAN."

    # round all values to 2 digits
    df = df.astype(float).round(2)

    # add back the row ids
    names = ["id"]
    names.extend(list(df.columns))
    df["id"] = records
    df = df[names]

    # add the cluster labels
    df["Cluster Labels"] = algo.labels_
    df["Cluster Labels"] = 1 + df["Cluster Labels"]

    cluster_message = "Found " + str(len(df["Cluster Labels"].unique())) + " clusters."

    # save the results in the hidden div
    data = df.to_json(orient="split")

    # display the results in the table
    table_data = df.to_dict("records")
    table_columns = [{"id": x, "name": x} for x in list(df.columns)]

    # create the list of features to be shown in the X, Y, Z dropdown menus
    names = list(df.columns)
    names.remove("id")
    names.remove("Cluster Labels")

    plot_options = [{"value": names[0], "label": names[0]}]

    if len(names) > 1:
        for j in range(1, len(names)):
            plot_options.append({"value": names[j], "label": names[j]})

    x_options = plot_options
    y_options = plot_options
    z_options = plot_options

    return table_data, table_columns, x_options, y_options, z_options, {"data": data}, \
           features_message, weights_message, transform_message, sample_message, reduction_message, \
           algo_message, cluster_message

@app.callback(Output("cluster_plot", "figure"), [Input("clustering_output", "children"),
               Input("x-axis", "value"), Input("y-axis", "value"), Input("z-axis", "value")])
def scatter_plot(clustering_output, x_axis, y_axis, z_axis):

    # load the clustering results from the hidden div
    df = pd.read_json(clustering_output["data"], orient="split")

    # drop the row ids
    df.drop("id", axis=1, inplace=True)

    if x_axis is None or y_axis is None:

        # chart layout
        layout = dict(margin=dict(t=30), font=dict(family="Open Sans"), paper_bgcolor="white",
        xaxis=dict(zeroline=False, showgrid=True, mirror=True, linecolor="#d9d9d9", tickangle=0, title_text=df.columns[0]),
        yaxis=dict(zeroline=False, showgrid=True, mirror=True, linecolor="#d9d9d9", tickangle=0, title_text=df.columns[1]))

        # chart traces
        traces = []
        traces.append(go.Scatter(x=list(df.iloc[:,0]), y=list(df.iloc[:,1]), mode="markers", hoverinfo="text",
                        text=["Cluster " + str(x) for x in list(df["Cluster Labels"])],
                                marker=dict(color=list(df["Cluster Labels"]), colorscale="Spectral",
                                            size=10, line=dict(width=1))))

        # chart object
        scatter_plot = go.Figure(data=traces, layout=layout).to_dict()

    elif x_axis is not None and y_axis is not None and z_axis is None:

        # chart layout
        layout = dict(margin=dict(t=30), font=dict(family="Open Sans"), paper_bgcolor="white",
        xaxis=dict(zeroline=False, showgrid=True, mirror=True, linecolor="#d9d9d9", tickangle=0, title_text=x_axis),
        yaxis=dict(zeroline=False, showgrid=True, mirror=True, linecolor="#d9d9d9", tickangle=0, title_text=y_axis))

        # chart traces
        traces = []
        traces.append(go.Scatter(x=list(df[x_axis]), y=list(df[y_axis]), mode="markers", hoverinfo="text",
                        text=["Cluster " + str(x) for x in list(df["Cluster Labels"])],
                            marker=dict(color=list(df["Cluster Labels"]), colorscale="Spectral",
                                        size=10, line=dict(width=1))))

        # chart object
        scatter_plot = go.Figure(data=traces, layout=layout).to_dict()

    elif x_axis is not None and y_axis is not None and z_axis is not None:

        # chart layout
        layout = dict(margin=dict(t=0, b=10, l=0, r=0, pad=0), font=dict(family="Open Sans"),
        plot_bgcolor="white", paper_bgcolor="white", scene=dict(bgcolor="white",
        xaxis=dict(zeroline=False, showgrid=True, mirror=True, linecolor="#d9d9d9", tickangle=0, title_text=x_axis),
        yaxis=dict(zeroline=False, showgrid=True, mirror=True, linecolor="#d9d9d9", tickangle=0, title_text=y_axis),
        zaxis=dict(zeroline=False, showgrid=True, mirror=True, linecolor="#d9d9d9", tickangle=0, title_text=z_axis)))

        # chart traces
        traces = []
        traces.append(go.Scatter3d(x=list(df[x_axis]), y=list(df[y_axis]), z=list(df[z_axis]), mode="markers",
                        hoverinfo="text", text=["Cluster " + str(x) for x in list(df["Cluster Labels"])],
                            marker=dict(color=list(df["Cluster Labels"]), colorscale="Spectral",
                                        size=7, line=dict(width=2))))

        # chart object
        scatter_plot = go.Figure(data=traces, layout=layout).to_dict()

    return scatter_plot

@app.callback([Output("link", "href"), Output("link", "download")],
              [Input("download_button", "n_clicks"), Input("clustering_output", "children")])
def download_file(n_clicks, clustering_output):

    # load the clustering results from the hidden div
    df = pd.read_json(clustering_output["data"], orient="split")

    # convert the table to csv
    csv = df.to_csv(index=False, encoding="utf-8")

    # create the file for download
    file_for_download = "data:text/csv;charset=utf-8," + urllib.parse.quote(csv)

    # use the current time as the file name
    file_name = "clustering_" + datetime.now().strftime("%Y%m%d_%H%M") + ".csv"

    return file_for_download, file_name

if __name__ == "__main__":
    app.run_server(port=8080, debug=False) # use this for running on local machine
    #application.run_server(port=8080, debug=False) # use this for deploying on AWS
